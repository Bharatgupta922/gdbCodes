/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
 double p , r , n , t, ci;
 printf("enter the principle value ");
 scanf("%lf",&p);
  printf("enter the rate  value ");
  scanf("%lf",&r);
   printf("enter the no of times compounded ");
   scanf("%lf",&n);
    printf("enter the no. of years");
    scanf("%lf",&t);
    ci=p*(pow((1+r/n),n*t));
    printf("\n the compound interest is %lf",ci);

    return 0;
}
