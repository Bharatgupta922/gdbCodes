#include<bits/stdc++.h>  

using namespace std;
void swap (int *a, int *b)  
{  
   int temp = *a;  
   *a = *b;  
   *b = temp;  
}
void printArray (int arr[], int n)  
{  
   int y=0,a[4][3]={0};
  for(int i =0;i<3;i++){
  for(int j =0;j<3;j++)
  a[i][j]=arr[y++];
  }
  a[3][1]=arr[y++];
  for(int i =0;i<3;i++){
      for(int j=0;j<3;j++){
          cout<<a[i][j]<<" ";
      }
      cout<<endl;
  }
  cout<<"  "<<a[3][1];
  cout<<endl;
}  
void randomize (int arr[], int n)  
{  
   srand (time(NULL));  
   for (int i = n - 1; i > 0; i--)  
   { 
       int j = rand() % (i + 1);  
       swap(&arr[i], &arr[j]);  
   }  
}
int main()  
{  
   int pin[4];
   int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};  
   int n = sizeof(arr) / sizeof(arr[0]);  
    for(int i=0; i<4; i++)
    {
       randomize (arr, n); 
       printArray(arr, n);
       cin>>pin[i];

    }
    cout<<"Your PIN Number is : ";
    for(int j=0; j<4; j++)
       {
           cout<<pin[j];
       }
   return 0;  
}
