#include <iostream>
using namespace std;
struct node 
{
    int data ;
    node * link;
};
int main(){
   node * x = new node();
   node * y = new node();
   node * z = new node();
   node * head = NULL;
   node * tail =NULL;
   int count=0;
   head=x;
   x->data=1;
   x->link=y;
   y->data=2;
   y->link=z;
   z->data=3;
   z->link=NULL;
   tail=z;
   node * temp = head;
   while(temp!=NULL)
   {
       count++;
       temp=temp->link;
   }
   cout<<count<<" ";
   
   
    return 0;
}