/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   // Write Your Code
int a,b,c,d,e;
scanf("%d",&a);
if (a>=90 && a<100){
  printf("Grade A+");
}
else if (a<90 && a>=80){
    printf("grade A");
}
else if (a>=70 && a<80){
    printf("Grade B");
}
else if (a>=60 && a<70){
    printf("Grade C");
}
else if (a>=50 && a<60){
    printf("Grade D");
}
else if (a<50 && a>=0){
    printf("Grade F");
}
else{
  printf("Wrong Entry ");
}





    return 0;
}

