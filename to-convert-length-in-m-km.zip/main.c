/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    double lcm,lm,lkm ;
printf("enter the length in cm\n ");
scanf("%lf",&lcm);
lm=lcm/100;
printf("length in meter %lf\n",lm);
lkm=lm/1000;
printf("length in kilometer %lf\n",lkm);

    return 0;
}
