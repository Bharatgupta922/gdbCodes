/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
// Write Your Code
int a ;
scanf("%d",&a);
if(a>=75)
{
   printf("Distinction");
  printf(" %d",a);
}
else if (a>=60 && a<75)
{
  printf("First division");
  printf(" %d",a);
}
else if (a>=50 && a<60)
{
  printf("Second division");
  printf(" %d",a);
}
else if (a>40 && a<50)
{
  printf("Third division");
  printf(" %d",a);
}
else {
  printf("Fail");
  printf(" %d",a);
}

    return 0;
}
