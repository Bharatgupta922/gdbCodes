/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  // Write your code
int b;
float hra,da,g;
scanf("%d",&b);
if(b<=10000){
  hra = 0.2*(float)b;
  da = 0.7*(float)b;
  g = b+hra +da+500;
}
if (b>10000 && b<=30000){
  hra = 0.25*(float)b;
  da = 0.8*(float)b;
  g =b+ hra +da +1000;
}
 if (b>30000 && b<=50000){
  hra = 0.3*(float)b;
  da  = 0.9*(float)b;
  g = b+hra +da+1500;
}
if (b > 50000){
  hra = 0.35*(float)b;
da = 0.95*(float)b;
  g = b+hra + da +2000;
}
printf("Basic Salary:%d",b);
printf("\nGross Salary:%f",g);

    return 0;
}
