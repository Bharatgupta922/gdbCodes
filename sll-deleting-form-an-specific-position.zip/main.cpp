#include<iostream>
using namespace std;

struct node{
    int data;
    node * next;
};
node *head =NULL;
node *tail = NULL;
void  deleteNode(int n){
    int i =1;
    node *temp=head ;
    n--;
    while(i<n){
        temp=temp->next;
        i++;
    }
    node *tmp=temp->next->next;
    temp->next=tmp;
}
void addNode(){
    node *temp = new node();
       cin>>temp->data;
    temp->next=NULL;
    if(head==NULL){
       head = temp;
       tail=temp;
    }
    else {
        tail->next= temp;
        tail=tail->next;
    }
}
void display(){
    cout<<endl;
    node *y = head ;
    while(y!=NULL){
        cout<<y->data<<"  ";
        y=y->next;
    }
}
int main()
{
 int n ;
 cin>>n;
 for(int i =0;i<n;i++)addNode();
 cout<<"enter the position that you want to delete ";
 int pos ;
 cin>>pos;
 if(pos>n)cout<<"it doesn't exist";
 else  deleteNode(pos);
 display();
    return 0;
}
