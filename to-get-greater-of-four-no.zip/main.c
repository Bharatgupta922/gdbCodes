/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  // Write your Code
int a,b,c,d;
scanf("%d",&a);
printf("\n");
scanf("%d",&b);
printf("\n");
scanf("%d",&c);
printf("\n");
scanf("%d",&d);
if(a>b&a>c&a>d){
  printf("%d",a);
}
else if (b>a&b>c&b>d){
  printf("%d",b);
}
else if (c>a&c>b&c>d){
  printf("%d",c);
}
else{
printf("%d",d);
}

    return 0;
}
