#include <stdio.h>
#include<math.h>
int octaltohexa(int n );
int main()
{
int n ;
scanf("%d",&n);
int result = octaltohexa(n );
printf("%x",result);

    return 0;
}
int octaltohexa(int n ){
    int b,sum=0,i=0;
    while(n!=0){
        b=n%10;
        sum+=b*pow(8,i);
        i++;
        n/=10;
    }
    return sum;
}