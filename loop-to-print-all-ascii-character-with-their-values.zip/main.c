/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
//   for(int i =0;i<=122;i++){
//       printf("%c %d\n",i,i);
//   }


  
//   int i = 0;
//   while(i<=122){
//       printf("%c %d\n",i,i);
//       i++;
// }

// int i =0;
// do{
//   printf("%c %d\n",i,i);
//   i++;
// }while(i<=122);
    return 0;
}

