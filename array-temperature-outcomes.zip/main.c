/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int n ;
  scanf("%d",&n);
  float a[n][4],actual,normal;
  for(int i =0;i<n;i++)
  for(int j =0;j<4;j++)
  scanf("%f",&a[i][j]);
  for(int i =0;i<n;i++){
      actual=0;
      normal=0;
      for(int j =0;j<4;j++){
          if(j<2)
          actual+=a[i][j];
          else
          normal+=a[i][j];
      }
      actual/=2;
      normal/=2;
float  result=actual-normal;
      if(result>0){
      printf("%.1f DEGREES(S) ABOVE NORMAL\n",result);
      }
      else{
          float final = -result;
          printf("%.1f DEGREES(S) BELOW NORMAL\n",final);
      }
  }

    return 0;
}
