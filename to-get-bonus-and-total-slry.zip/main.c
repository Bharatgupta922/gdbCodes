/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
//Write your code
int s ;
float b,t ;
scanf("%d",&s);
if(s<=25000){
  b = 0.2*(float)s;
}
if(s<=50000 && s>25000){
  b = 0.15*(float)s;
}
if(s<=100000 && s>50000){
  b = 0.1*(float)s;
}
if(s>100000){
  b = 0.05*(float)s;
}
t = b+s;
printf("Salary=%d",s);
printf("\nBonus=%f",b);
printf("\nTotal_salary=%f",t);



    return 0;
}
