/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int N,n,b,sum=0;
  scanf("%d",&N);
  for(int i=1;i<=N;i++){
    scanf("%d",&n);
    do{
      b=n%10;
      sum+=b;
      n/=10;
    }while(n!=0);
        printf("%d\n",sum);
    sum =0;
  }

    return 0;
}
