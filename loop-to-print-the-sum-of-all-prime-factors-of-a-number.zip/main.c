/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int n,sum  =0,fact;
scanf("%d",&n);
for(int i =1;i<=n;i++){
    fact = 0 ;
    if(n%i==0){
        for(int j =1;j<=i;j++){
            if(i%j==0)
            fact++;
        }
        if(fact == 2)
            sum+=i;
        
        }
}
printf("%d",sum);

    return 0;
}
