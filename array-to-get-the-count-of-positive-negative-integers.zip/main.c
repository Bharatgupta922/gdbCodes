/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int n,positive=0,negative=0;
    printf("ENTER THE SIZE OF THE MATRIX :\n");
  scanf("%d",&n);
int a[n];
printf("ENTER THE MATRIX :\n");
for(int i =0;i<n;i++)
scanf("%d",&a[i]);
for(int j=0;j<n;j++ ){
    if(a[j]>=0)
    positive++;
   else
   negative++;
}
printf("positive no.s are :%d\n",positive);
printf("positive no.s are :%d\n",negative);

    return 0;
}
