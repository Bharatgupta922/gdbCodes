/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int n;
scanf("%d",&n);
int a[n];
for(int i =0;i<n;i++){
    scanf("%d",&a[i]);
}
int freq[n],c;
for(int i =0;i<n;i++)
freq[i]=-1;
for(int i =0;i<n;i++){
    c=1;
    for(int j =i+1;j<n;j++){
        if(a[i]==a[j]){
            freq[j]=0;
            c++;
        }
        
    }
    if(c>0&&freq[i]!=0){
        printf("%d-%d\n",a[i],c);
    }
}
    return 0;
}
