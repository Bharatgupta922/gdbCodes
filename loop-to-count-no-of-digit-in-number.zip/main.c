/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
// int a,b=0 ;
// scanf("%d",&a);
// while(a!=0){
//     b++;
//     a/=10;
// }
// printf("%d",b);

// int a,b=0;
// scanf("%d",&a);
// do{
//     b++;
//     a/=10;
// }while(a!=0);
// printf("%d",b);
    return 0;
}
