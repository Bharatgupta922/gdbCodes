/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int n,a,sum=0,fact,temp ;
 scanf("%d",&n);
 temp=n;
while(temp>0){
     fact=1;
     a=temp%10;
     for(int j =a;j>1;j--){
        fact = fact*j; 
     }
     sum+=fact;
     temp/=10;
 }
if(sum==n)
printf("yes");
else
printf("no");
    return 0;
}
