#include<iostream>
using namespace std ;
struct node {
    int data ;
    node * next =NULL;
    node * prev =NULL;
};
node * head =NULL;
node * tail = NULL;
  node * y = head;
void addnodeOrinsertAtend(){
    node * temp = new node();
     cin>>temp->data;
    temp->next=NULL;
    temp->prev=NULL;
    if(head==NULL)head=tail=y=temp;
    else {
       y->next=temp;
       temp->prev=y;
       y=y->next;
         tail=y;
    }
}
void deletefrombeg(){
    head = head->next;
}
void deletefromend(){
    tail=tail->prev;
    tail->next=NULL;
}
void display(){
    cout<<endl;
    node *y = head ;
    while(y!=NULL){
        cout<<y->data<<"  ";
        y=y->next;
    }
}
int count(){
    node * x = head ;
    int i =0;
    while(x!=NULL){
        x=x->next;
       i++;
    }
    cout<<i<<"vjgvzcjbhvasdk b";
    return i ;
}
void deletefromspec(){
     int pos,i=1 ;
     int n = count();
     cin>>pos ;
     node * x = head ;
     if(i==1){
         deletefrombeg();
         return ;
     }
     else if(i==n){
         deletefromend();
         return ;
     }else {
     while(i<pos){
         x=x->next;
         i++;
     }
     x->prev->next=x->next;
     x->next->prev=x->prev;
     }
}
int main (){
int n ;
cin>>n;
while(n--)addnodeOrinsertAtend();
display();
cout<<endl<<"-------------------------------------------------------"<<endl;
cout<<endl<<"delete from beginning "<<endl;
deletefrombeg();
display();
cout<<endl<<"----------------------------------------------------"<<endl;
cout<<"deleting from end"<<endl;
deletefromend();
display();
cout<<endl<<"----------------------------------------------------"<<endl;
cout<<"deleting from the specific position ";
cout<<endl<<"insert the position which you wannt to delete "<<endl;
deletefromspec();
display();

    return 0;
}
