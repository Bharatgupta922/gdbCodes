/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int a ,b,c,d,num,sum=0;
printf("Enter a four digit number ");
scanf("%d",&a);
num=a%10;
if(num==9)
{
num=0;
}
else 
{
num+=1;
}
a=a/10;
b=a%10;
if(b==9)
{
b=0;
}
else 
{
b+=1;
}
a=a/10;
c=a%10;
if(c==9)
{
c=0;
}
else
{
c+=1;
}
a=a/10;
d=a;
if(d==9)
{
d=0;
}
else
{
d+=1;   
} 

sum+=d*1000+c*100+b*10+num;
printf("%d",sum);






    return 0;
}
