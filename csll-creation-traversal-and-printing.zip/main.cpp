#include<iostream>
using namespace std ;
struct node{
    int data ;
    node * next=NULL;
};
node * head = NULL;
node * tail = NULL;
void addNode(){
    node * temp = new node();
  cin>>temp->data;
  if(head==NULL)head=tail=temp;
  else {
      tail->next = temp;
      tail = temp;
  }
}
void display(){
    node * x = head  ;
   do{
       cout<<x->data<<" ";
       x=x->next;
   }while(x!=head);
}
int main (){
    int n ;
    cin>>n;
    while(n--)addNode();
    tail->next=head;
    cout<<endl;
    display();
    cout<<endl<<"----------------------------------------------------------------------------"<<endl;

    return 0 ;
    
}