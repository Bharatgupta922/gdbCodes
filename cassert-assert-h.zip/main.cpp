#include<iostream>
#include<cassert>
using namespace std;
void print_number(int * myInt){
    assert(myInt!=NULL);
    cout<<*myInt<<endl;
}
int main(){
    int a=10;
    int * b = NULL;
    int * c = NULL;
    b=&a;
    print_number(b);
    print_number(c);
    return 0;
}