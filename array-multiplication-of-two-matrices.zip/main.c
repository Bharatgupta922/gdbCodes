/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int m,n,p,q;
scanf("%d%d%d%d",&m,&n,&p,&q);
if(n!=p){
    printf("MATRIX MULTIPLICATION IS NOT POSSIBLE");
    }
    else{
        int a[m][n],b[p][q],c[m][q],sum;
        for(int i=0;i<m;i++)
        for(int j=0;j<n;j++)
        scanf("%d",&a[i][j]);
        for(int i=0;i<p;i++)
        for(int j=0;j<q;j++)
        scanf("%d",&b[i][j]);
        for(int i=0;i<m;i++)
        for(int j=0;j<q;j++){
        sum=0;
        for(int k=0;k<n;k++)
        sum+=a[i][k]*b[k][j];
        c[i][j]=sum;
        }
        for(int i=0;i<m;i++){
        for(int j=0;j<q;j++)
        printf("%d ",c[i][j]);
        printf("\n");
        }
    }

    return 0;
}

