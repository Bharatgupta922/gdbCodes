/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void ncount( ){
static int k ;
int i =0,a=0;
    do{
        scanf("%d",&i);
        if(k!=i&&i!=-1)a++;
        k=i;
    }while(k!=-1);
    printf("%d",a);

}
int main()
{
    ncount();
    return 0;
}
