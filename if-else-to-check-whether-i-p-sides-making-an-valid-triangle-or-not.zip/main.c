/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  float a,b,c ;
  scanf("%f",&a);
    scanf("%f",&b);
      scanf("%f",&c);
  if (a+b>c ||b+c==a||c+a>b){
      printf("it is an valid triangle");
  }
else {
    printf("it is not an valid triangle");
}
    return 0;
}
