#include<iostream>
#include<cstring>
#include<climits>
#include<cstdbool>
using namespace std ;
struct flight{
    char flightno[2];
    char timing[5];
    int duration ;
    int price ;
};
int main(){
    int t ;
    cin>>t;
    while(t--){
   int n ;
   cin>>n;
   char result[6];
   struct flight arr[n];
   for(int i = 0 ; i<n;i++)
       cin>>arr[i].flightno>>arr[i].timing>>arr[i].duration>>arr[i].price;
       bool  visited[n] = {false};
       int first = INT_MAX,second = INT_MAX ,firstindex = 0,secondindex = 0;
       for(int count = 1;count<=3;count++){
       for(int i=0;i<n;i++){
           if((first > arr[i].price) && (!visited[i])){
               second = first ;
               firstindex = secondindex = i;
               first = arr[i].price;
           }
           if((second > arr[i].price) && (!visited[i])){
            second = arr[i].price;
           secondindex = i;
           }
       }
    //   if(first == second ){
    //       if(arr[firstindex].duration == arr[secondindex].duration)
    // strcmp(arr[firstindex].timing,arr[secondindex].timing)<0?strcpy(result,arr[firstindex].flightno),visited[firstindex]=true:strcpy(result,arr[secondindex].flightno),visited[secondindex]=true;
    //       else arr[firstindex].duration<arr[secondindex].duration?strcpy(result,arr[firstindex].flightno),visited[firstindex]=true:strcpy(result,arr[secondindex].flightno),visited[secondindex]=true;
    //   }
    //   else first<second?strcpy(result,arr[firstindex].flightno),visited[firstindex]=true:strcpy(result,arr[secondindex].flightno),visited[secondindex]=true;
      
    //   cout<<result[0]<<result[1];
    if(first == second){
        if(arr[firstindex].duration == arr[secondindex].duration){
            if(strcmp(arr[firstindex].timing,arr[secondindex].timing)<0){
                strcpy(result,arr[firstindex].flightno);
                visited[firstindex]=true;
            }
            else {
                strcpy(result,arr[secondindex].flightno);
                visited[secondindex]=true;
            }
        }
        else {
            if(arr[firstindex].duration<arr[secondindex].duration){
                 strcpy(result,arr[firstindex].flightno);
                visited[firstindex]=true;
            }
            else {
                strcpy(result,arr[secondindex].flightno);
                visited[secondindex]=true;
            }
        }
    }
    else {
        if(first<second){
            strcpy(result,arr[firstindex].flightno);
                visited[firstindex]=true;
        }
        else {
              strcpy(result,arr[secondindex].flightno);
                visited[secondindex]=true; 
        }
    }
    count<3?cout<<result[0]<<result[1]<<" ":cout<<result[0]<<result[1];
       }
       cout<<endl;
    }
      
    return 0;
}