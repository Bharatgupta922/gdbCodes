/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int n,num,b,reverse=0;
scanf("%d",&n);
num =n;
while(num>0){
    b=num%10;
    reverse = reverse*10+b;
    num/=10;
}
if(n==reverse){
    printf("%d is palindrome",n);
}
else{
    printf("%d is not in palindrome",n);
}

    return 0;
}
