/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

***************************************************************************************************************************/
#include <stdio.h>

int main()
{
     // int a=20 ,b=15,c,d,e,f,g;
    // c=a+b;
    // d=a-b;
    // e=a*b;
    // f=a/b;
    // g=a%b;
    // printf("%d\n",c);
    // printf("%d\n",d);
    // printf("%d\n",e);
    // printf("%d\n",f);
    // printf("%d\n",g);


//     int  a=15;
//     int  b=20;
//     float c = 25.99;
//     float d =30.47;
//   printf("\n");
//     printf("%d\n",a++);
//         printf("%d\n",b--);
//             printf("%f\n",c++);
//                 printf("%f\n",d--);




// int a=10,b=20;
// printf("%d\n",a>b);
// printf("%d\n",a<b);
// printf("%d\n",a>=b);
// printf("%d\n",a<=b);
// printf("%d\n",a==b);
// printf("%d\n",a!=b);


// #include<stdio.h>
// int main( )
// {
//  int i ;
//  for ( i = 1 ; i <= 5 ; printf("%d", i))
// 	i++;
//  return 0;
// }

#include <stdio.h>

// int main()
// {
//   int var1, var2;
//   for(var1 = 1; var1 <= 5; var1++)
//   {
//     for(var2 = 1; var2 <= 5; var2++)
//     {
//       if(var2==3)
//         break;  // it will cause exit from inner loop.
//       printf("var1 = %d, var2 = %d\n", var1, var2);
//     }
//     printf("After second loop.\n"); // it will execute after the break statement. as it is in outer loop.
//   }
//   printf("After both loops.");
//   return 0;
// }

    return 0;
}


