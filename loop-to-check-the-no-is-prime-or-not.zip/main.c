/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
//     int n ,a=1;
    
//     scanf("%d",&n);
   
//    for(int i=2;i<=(n-1);i++){
//         if(n%i==0){
//             a=0;
//         }
        
//     }
       
//   
//   if(n<2){
//       a=0;
//   }
//     printf("%d",a);



//      int n ,a=1,i=2;
    
//     scanf("%d",&n);
//   while(i<=(n-1)){
       
//           if(n%i==0){
//               a=0;
//           }
//       i++;
//   }
//   if(n<2){
//       a=0;
//   }
//   printf("%d",a);



//      int n ,a=1,i=2;
    
//      scanf("%d",&n);
// do{
//     if(n%i==0){
//         a=0;
//     }
//     i++;
// }while(i<=(n-1));
//  if(n<2){
//      a=0;
//  }
// printf("%d",a);
    return 0;
}

