#include<iostream>
#include<ctime>
#include<cstdlib>
#define n 3
using namespace std ;
void display(int a[n][n]){
    for(int i =0;i<n;i++){
        for(int j =0;j<n;j++)
        cout<<a[i][j]<<"\t";
        cout<<endl;
    }
}
void rotateMatrix(int a[][n]) 
{ 
    for (int x = 0; x < N / 2; x++) { 
        for (int y = x; y < N-x-1; y++) { 
            int temp = mat[x][y]; 
            mat[x][y] = mat[y][N-1-x]; 
        mat[y][N-1-x] = mat[N-1-x][N-1-y]; 
     mat[N-1-x][N-1-y] = mat[N-1-y][x]; 
            mat[N-1-y][x] = temp; 
        } 
    } 
} 
void fun9(int a[n][n]){
    int i ,k=0,l=0,b[9]={0},y=0;
    int last_row=2,last_col = 2;
    while(k<=last_row&&l<=last_col){
for(int i=k;i<=last_col;i++){
    b[y++]=a[k][i];
}
k++;
for(i=k;i<=last_row;i++){
    b[y++]=a[i][last_col];
}
last_col--;
if(k<=last_row){
    for(i=last_col;i>=l;i--){
        b[y++]=a[last_row][i];
    }

    last_row--;
}
    if(l<=last_col){
        for(i=last_row;i>=k;i--){
            b[y++]=a[i][l];
        }
        l++;
    }
    }
    y=0;
    for(int p=0;p<n;p++)
    for(int q=0;q<n;q++)
    a[p][q]=b[y++];
    display(a);
}

int main(){
    int a[3][3]={1,2,3,4,5,6,7,8,9};
    // srand(time(0));
    // int x = rand()*15+1;
    /*/ if(x==1)*/fun9(a);
    // else if (x==2)fun2(a);
    // else if(x==3)fun3(a);
    // else if(x==4)fun4(a);
    // else if (x==5)fun5(a);
    // else if (x==6)fun6(a);
    // else if (x==7)fun7(a);
    // else if (x==8)fun8(a);
    // else if (x==9)fun9(a);
    // else if (x==10)fun10(a);
    // else if (x==11)fun11(a);
    // else if (x==12)fun12(a);
    // else if (x==13)fun13(a);
    // else if (x==14)fun14(a);
    // else  (x==15)fun15(a);
    
    return 0;
}
