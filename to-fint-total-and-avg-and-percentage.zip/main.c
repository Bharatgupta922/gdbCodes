/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int a,b,c,d,e,total;
  float avg,percentage;
  printf("\nenter marks in physics");
  scanf("%d",&a);
    printf("\nenter marks in chemistry");
  scanf("%d",&b);
    printf("\nenter marks in mathematics");
  scanf("%d",&c);
    printf("\nenter marks in english");
  scanf("%d",&d);
    printf("\nenter marks in ip");
  scanf("%d",&e);
  total = a+b+c+d+e;
  printf("\nyour total is %d",total);
  avg=total/5;
  printf("\n your average is %f ",avg);
  percentage = avg ;
printf("\n your percentage %f ",percentage);
  return 0;
}
