/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
    int n ;
    scanf("%d",&n);
   int ia;
  float fb;
  fb = sqrt(n);
  ia=fb;
  if(ia==fb){
    printf("yes");
  }
  else{
    printf("no");
  }

    return 0;
}

