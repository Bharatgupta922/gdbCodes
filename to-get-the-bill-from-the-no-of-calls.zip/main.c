/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a,b;
scanf("%d",&a);
if(a>0 && a<=100){
  b=500;
}
else if (a>100 && a<=150){
  b = 500 + 3*(a-100);
}
else if (a>150 && a<=200){
  b = 500 + 3*50 + 2*(a-150);
}
else {
  b = 500 + 3*50+2*50 + (a-200);
}
printf("Calls:%d",a);
printf("\nBill:%d",b);

    return 0;
}
