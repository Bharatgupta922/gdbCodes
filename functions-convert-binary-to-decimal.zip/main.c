  #include <stdio.h>
  #include<math.h> 
  int decimal(int n);
    int main() 
    { 
    int n,b;
    scanf("%d",&n);
   int result = decimal(n);
   printf("%d",result);
    }
    int decimal(int n ){
        int a=0,result=0,b;
        int i =0;
while(n>0){
    b=n%10;
    result+=b*pow(2,i);
    i++;
n/=10;
}
return result;

    } 
