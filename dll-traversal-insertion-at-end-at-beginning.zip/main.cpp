#include<iostream>
using namespace std ;

struct node {
    int data ;
    node * next =NULL;
    node * prev =NULL;
};
node * head =NULL;
node * tail = NULL;
  node * y = head;
void addnodeOrinsertAtend(){
    node * temp = new node();
     cin>>temp->data;
    temp->next=NULL;
    temp->prev=NULL;
    if(head==NULL)head=tail=y=temp;
    else {
       y->next=temp;
       temp->prev=y;
       y=y->next;
         tail=y;
    }
}
void addAtspecfic(int pos){
    node * temp = new node();
    cin>>temp->data;
    node * x = head ;
    int i =1;
    while(i<pos-1){
        x=x->next;
        i++;
    }
   temp->prev=x;
   temp->next=x->next;
   x->next=temp;
   temp->next->prev=temp;
     }
void insertAtbeg(){
    node * temp = new node();
    cin>>temp->data;
    temp->next = head;
    head ->prev = temp;
    head = temp;
}

void display(){
   node * x = head;
    while(x!=NULL){
        cout<<x->data<<" ";
        x=x->next;
    }
}
int main()
{
int n ;
cin>>n;
while(n--)addnodeOrinsertAtend();
display();
cout<<endl<<"------------------------------------------"<<endl;
cout<<"enter the data of node that you want insert at beginning "<<endl;
insertAtbeg();
display();
cout<<endl<<"-------------------------------------------"<<endl;
cout<<"enter the data of node that you want to insert at end"<<endl;
addnodeOrinsertAtend();
display();
cout<<endl<<"-----------------------------------------------"<<endl;
cout<<"enter the position and data of the node that you want to insert at specific position"<<endl;
int pos ;
cin>>pos;
addAtspecfic(pos);
display();

    return 0;
}
