/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
//   int size,pos;
//   scanf("%d",&size);
//   int a[size];
//   for(int i =0;i<size;i++)
//   scanf("%d",&a[i]);
//   scanf("%d",&pos);
//   for(int i =pos;i<size;i++)
// {
//     a[i-1]=a[i];
// }
// for(int i =0;i<size-1;i++)
// printf("%d",a[i]);


// or 


  int size,pos;
  scanf("%d",&size);
  int a[size];
  for(int i =0;i<size;i++)
  scanf("%d",&a[i]);
  scanf("%d",&pos);
  for(int i =pos-1;i<size-1;i++)
{
    a[i]=a[i+1];
}
for(int i =0;i<size-1;i++)
printf("%d",a[i]);
    return 0;
}
