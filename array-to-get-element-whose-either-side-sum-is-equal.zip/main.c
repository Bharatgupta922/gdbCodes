/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int n ,psum,fsum;
   scanf("%d",&n);
   int a[n];
   for(int i =0;i<n;i++)
   scanf("%d",&a[i]);
   for(int i =0;i<n;i++){
       psum=0;
       fsum=0;
       for(int j=0;j<i;j++)
       psum+=a[j];
       for(int k=i+1;k<n;k++)
       fsum+=a[k];
      if(psum==fsum){
      printf("%d",a[i]);
       break;
      }
      }

    return 0;
}
