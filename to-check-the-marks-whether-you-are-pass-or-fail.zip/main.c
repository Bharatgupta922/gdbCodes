/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int marks ;
 printf("enter the total marks ");
 scanf("%d",&marks);
 if (marks>33)
 {
 printf("\n you are passed ");
 if(marks>=90)
 printf("\n you have first division ");
 }
 else 
 {
     printf("\n you are fail work hard ");
 }

    return 0;
}
