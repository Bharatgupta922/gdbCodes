/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
//   int sum=0;
//   for(int i =1;i<=100;i++){
//       if(i%2!=0){
//           sum+=i;
//       }
//   }
//   printf("%d",sum);



// int sum=0,i=1;
// while(i<=100){
//     if(i%2!=0){
//         sum+=i;
//     }
//     i++;
// }
// printf("%d",sum);


// int sum=0,i=1;
// do{
//     if(i%2!=0){
//         sum+=i;
//     }
//     i++;
// }while(i<=100);
// printf("%d",sum);

    return 0;
}
