/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int m,n;
scanf("%d%d",&m,&n);
int a[m][n];
for(int i =0;i<m;i++)
for(int j =0;j<n;j++)
scanf("%d",&a[i][j]);
int sum;
for(int i =0;i<m;i++){
    sum=0;
for(int j =0;j<n;j++){
if(a[j][i]%2==0)
sum+=a[j][i];
}
printf("%d\n",sum);
}
    return 0;
}
