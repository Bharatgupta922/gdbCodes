#include <iostream>
using namespace std ;
struct node {
    int data ;
    node * next=NULL ;
};
node * head = NULL;
node * tail = NULL;
void reverse(){
    node * prevnode =NULL;
    node * curnode =head ;
    node * nextnode=head;
    while(nextnode!=NULL){
        nextnode = nextnode->next;
        curnode->next=prevnode;
        prevnode = curnode;
        curnode=nextnode;
    }
    head = prevnode;
}
void addNode(){
    node *temp = new node();
       cin>>temp->data;
    temp->next=NULL;
    if(head==NULL){
       head = temp;
       tail=temp;
    }
    else {
        tail->next= temp;
        tail=tail->next;
    }
}
void display(){
    cout<<endl;
    node * y = head ;
    while(y!=NULL){
        cout<<y->data<<"  ";
        y=y->next;
    }
}
int main()
{
 int n ;
 cin>>n;
 while(n--)addNode();
 display();
 reverse();
 display();

    return 0;
}

