#include<iostream>
using namespace std ;
int myFunction(int* integer,int arraySize,int i){
    (i<arraySize)?printf("%c",*((int *)integer + i++)),
    myFunction(integer,arraySize,i):0;
}
int main(){
    int array[]={72,101,108,108,111,32,87,111,114,108,100,33};
    myFunction((int *)array,12,0);
    return 0;
}   

