#include<iostream>
using namespace std ;
struct node {
    int data ;
    node * next=NULL ;
    node * prev=NULL;
};
node * head = NULL;
node * tail = NULL;
  node * y = head;
void addnodeOrinsertAtend(){
    node * temp = new node();
     cin>>temp->data;
    temp->next=NULL;
    temp->prev=NULL;
    if(head==NULL)head=tail=y=temp;
    else {
       y->next=temp;
       temp->prev=y;
       y=y->next;
         tail=y;
    }
}
void display(){
   node * x = head;
    while(x!=NULL){
        cout<<x->data<<" ";
        x=x->next;
    }
}
void reversing(){
    node * temp=head ;
    node * temp2=;
    if(head==NULL)cout<<endl<<"list is empty "<<endl;
    else {
       temp2=temp->next;
       temp->prev=temp->prev;;
       temp=temp2;
       temp2=te 
    }
}
int main(){
    itn n ;
    cin>>n;
    while(n--)addnodeOrinsertAtend();
    display();
    cout<<endl<<"after reversing "<<endl;
    reversing();
    display();
    return 0;
}