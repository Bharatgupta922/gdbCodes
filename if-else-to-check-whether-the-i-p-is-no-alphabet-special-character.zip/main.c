/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  char a;
scanf("%c",&a);
if((a>='a'&& a<='z')||(a>='A'&& a<='Z') ){
    printf("it is an alphabet ");
}
else if (a>=48 && a<=57){
    printf("it is a number ");
}
else {
    printf("it is a special character ");
}

    return 0;
}
