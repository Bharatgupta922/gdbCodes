#include<iostream>
#include<stack>
using namespace std ;
int main(){
    stack <int> s;
    int noOfSlices ,types;
    cin>>noOfSlices;
    int temp=noOfSlices;
    cin>>types;
    int slices[types];
    for(int i=0;i<types;i++)
    cin>>slices[i];
    int b[types]={0},c[types],y=0;
    for(int i=0;i<types;i++)c[i]=-1;
    for(int i=types-1;i>=0;i--){
        if(noOfSlices>slices[i]){
            noOfSlices-=slices[i];
            b[y]=i;
            c[y]=0;
            y++;
        }
    }
    int count =0;
    for(int i=0;i<types;i++)if(b[i]>0||c[i]==0)count++;
    cout<<count<<endl;
    for(int i=0;i<count;i++)s.push(b[i]);
     while(!s.empty()){
        cout<<s.top()<<"  ";
        s.pop();
    }
}
