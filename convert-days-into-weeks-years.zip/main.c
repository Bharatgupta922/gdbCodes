/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int  days , weeks ,years;

printf("enter no. of days ");

scanf("%d",&days);

weeks= days/7;

printf("no. of weeks %d\n",weeks);

years = days/365;

printf("no. of years %d\n",years);

    return 0;
}
