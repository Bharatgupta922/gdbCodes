#include <stdio.h>

int main()
{
    int x=10;
    void * gp;
    gp=&x;
    printf("%d",*(int *)gp);
       char c='a'; 
        gp=&c;
    printf("\n%c",*(char *)gp);

    return 0;
}
