/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int n,a,b,rem,reverse=0;
scanf("%d",&n);
a=n;
while(a>0){
    rem=a%10;
    reverse=reverse*10+rem;
    a/=10;
}
while(reverse>0){
    b=reverse%10;
    if(b==0)
    printf("zero ");
     if(b==1)
    printf("one ");
     if(b==2)
    printf("two ");
     if(b==3)
    printf("three ");
     if(b==4)
    printf("four ");
      if(b==5)
    printf("five ");
      if(b==6)
    printf("six ");
      if(b==7)
    printf("seven ");
      if(b==8)
    printf("eight ");
      if(b==9)
    printf("nine ");
    
  reverse/=10;  

}



    return 0;
}
