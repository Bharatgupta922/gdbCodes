/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
// for(char c = 97;c<=122;c++){
//     printf("%c\n",c);
// }


// char c=97 ;
// while(c<=122){
//     printf("%c\n",c);
//     c++;
// }



// char c = 97;
// do {
//     printf("%c\n",c);
//     c++;
// }while(c<=122);
    return 0;
}
