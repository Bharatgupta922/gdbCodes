#include <iostream>
#include <string>
using namespace std;
class laptop{
    public:
string  laptopName,laptopBrand,laptopProcessor;
float laptopPrice ;
void getData(){
    cin>>laptopName;
    cin>>laptopBrand;
    cin>>laptopProcessor;
    cin>>laptopPrice;
}
void showData(){
    cout<<laptopName<<endl<<laptopBrand<<endl<<laptopProcessor<<endl<<laptopPrice<<endl;
}
void startup(){
    cout<<"laptop "<<laptopName<<" has started"<<endl;
}
void shutDown(){
    cout<<"laptop "<<laptopName<<" is shutting down."<<endl;
}
};
int main(){
    laptop laptop1;
    laptop1.getData();
    laptop1.showData();
    laptop1.startup();
    laptop1.shutDown();
    return 0;
}