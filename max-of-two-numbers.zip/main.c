/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,max;
  printf("enter the first no .");
  scanf("%d",&a);
  printf("\n enter the second no.");
  scanf("%d",&b);
  max=a>b?a:b;
  printf("\n the larget no. is %d",max);
  

    return 0;
}
