#include <stdio.h>
#include<math.h>
#include<stdbool.h>
#include<stdlib.h>
int compare(int ,int );
void swap(int * ,int *);
void BubbleSort(int * ,int ,int (*)());
int compare(int a,int b){
    return a-b;
}
void BubbleSort(int *a,int n,int (*compare)(int ,int)){
    bool sorted ;
    for(int i =0;i<n;i++){
        sorted =true ;
        for(int j =0;j<n-i-1;j++){
            if(compare(a[j],a[j+1])>0){
                swap(&a[j],&a[j+1]);
                sorted=false;
            }
        }
        if(sorted)break;
    }
}
void swap(int *a,int *b){
    int temp=*a;
    *a=*b;
    *b=temp;
}
int main()
{
 int t ;
 scanf("%d",&t);
 while(t--){
     int n ;
     scanf("%d",&n);
     int a[n];
     for(int i =0;i<n;i++)scanf("%d",(a+i));
     BubbleSort(a,n,compare);
     for(int i =0;i<n;i++)printf("%d ",a[i]);
     printf("\n");
 }

    return 0;
}

