/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a,b,c,d,e,percentage;
printf("enter marks in chemistry\n");
scanf("%d",&a);
printf("enter marks in physics\n");
scanf("%d",&b);
printf("enter marks in mathematics\n");
scanf("%d",&c);
printf("enter marks in english\n");
scanf("%d",&d);
printf("enter marks in informatics practices\n");
scanf("%d",&e);
percentage = (a+b+c+d+e)/5;
if (percentage>=90){
    printf("grade is A");
}
else if (percentage>=80 && percentage<90){
    printf("Grade is B");
}
else if (percentage>=70 && percentage<80){
    printf("Grade is C");
}
else if (percentage>=60 && percentage<70){
    printf("Grade is D");
}
else if (percentage>=50 && percentage<60){
    printf("Grade is E");
}
else if (percentage>=40 && percentage<50){
    printf("Grade is F");
}
else if (percentage<40){
    printf("Grade is F");
}

    return 0;
}

