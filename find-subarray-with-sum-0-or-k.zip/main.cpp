#include<iostream>
#include<unordered_set>
using namespace std ;
int main(){
    //  int a[] = {2,-1,3,4,2};
    //  bool found = false ;
    // unordered_set <int> s ;
    //  int sum = 0;
    //  for(int i = 0;i<5;i++){
    //      s.insert(sum);
    //      sum += a[i];
    //      if(s.find(sum)!=s.end()){
    //          found = true;
    //          break;
    //      }
    //  }
    //  if(found)cout<<"Found";
    //  else cout<<"Not Found";
     
     
        int a[] = {2,-1,3,4,2};
     bool found = false ;
    unordered_set <int> s ;
     int sum = 0,k = 3;
     for(int i = 0;i<5;i++){
         s.insert(sum);
         sum += a[i];
         if(s.find(sum-k)!=s.end()){
             found = true;
             break;
         }
     }
     if(found)cout<<"Found";
     else cout<<"Not Found";
     
    return 0;
}