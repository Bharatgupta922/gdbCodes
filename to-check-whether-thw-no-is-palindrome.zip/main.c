/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a ,num,b,c,d,e,sum=0;
  scanf("%d",&a);
  num = a;
  b = num %10;
  num /=10;
  c = num%10;
  num /=10;
  d = num%10;
  num /= 10;
  e = num ;
  sum = b*1000+c*100+d*10+e;
  if(sum==a){
    printf("Equal");
  }
  else {
    printf("Not Equal");
  }
 

    return 0;
}
