#include <stdio.h>
void QuickSort(int a[],int lb,int ub);
int partition(int *a,int lb,int ub);
void swap(int *a,int *b);
int main()
{
   int n ;
   scanf("%d",&n);
  int a[n];
   for(int i =0;i<n;i++)
   scanf("%d",(a+i));
QuickSort(a,0,n-1);
for(int i =0;i<n;i++)
printf("%d\n",i[a]);
return 0;
}
int partition(int *a,int l,int h){
    int i=l,j=h,pivot=a[l];
    while(i<j){
    do{
       i++; 
    }while(a[i]<=pivot);
    do{
        j--;
    }while(a[j]>pivot);
    swap(&a[i],&a[j]);
    }
    swap(&a[i],&a[j]);
    return j;
}

void swap(int *a,int *b){
    int temp=*a;
    *a=*b;
    *b=temp;
}
void QuickSort(int a[],int lb,int ub){
    if(lb<ub){
      int j = partition(a,lb,ub);
        QuickSort(a,lb,j);
        QuickSort(a,j+1,ub);
    }
}




