#include<iostream>
#include<limits>
#include <bits/stdc++.h> 
using namespace std ;
int main(){
    int t;
    cin>>t;
    while(t--){
        int n ;
        cin>>n;
        int a[n],max=INT_MIN,sum[n],cursum;
                for(int i =0;i<n;i++)cin>>a[i];
                sum[0]=a[0];
        for(int i =1;i<n;i++)sum[i]=a[i]+sum[i-1];
        for(int i=0;i<n;i++){
            for(int j =i;j<n;j++){
                cursum=sum[j]-sum[i]+a[i];
        //   int cursum=0;
        //   for(int k=i;k<=j;k++)cursum+=a[k];
           if(max<cursum)max=cursum;
            }
        }
       cout<<max<<endl; 
    }
    return 0 ;
}