/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   float a,b,c ;
  scanf("%f",&a);
    scanf("%f",&b);
      scanf("%f",&c);
      if (a==b && a==c){
          printf("it is an equilateral triangle ");
      }
else if (a==b||a==c||b==c){
    printf("it is an isosceles triangle ");
}
else {
    printf("it is an scalene triangle");
}
    return 0;
}
