/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int a,b,max ;
  scanf("%d",&a);
  scanf("%d",&b);
  if (a>b){
      max=a;
      printf("\nmaximum no. is %d",max);
  }
  
else if(a<b){
    max=b;
    printf("\nmaximum no. is %d",max);
}
else {
    printf("\nboth the no.'s are equal");
}
    return 0;
    
}
