#include <stdio.h>
#include<math.h>
int main()
{
int n,a,b,c,j=0,d,noOfDigits=0,sum=0;
 
  scanf("%d",&n);
   a = n;
  while(a != 0){
 
    a /= 10;
    ++j;
   
  }
  a = n;
  
  while(a != 0){
    c = a % 10;
    sum  += pow(c,j) ;
    a /= 10;
    
  }
  if(sum == n){
    printf("yes");
  }
  else{
    printf("no");
  }
    return 0;
}