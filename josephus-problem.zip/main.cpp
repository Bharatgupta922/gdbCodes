/* it is called josephus problem  
in this problem we have n number of persons standing in a circle according to the index 
now starting from zero index the sword been pass to k+1th  person after killing kth person 
this continue till the last person alive and he wins */
#include<iostream>
using namespace std ;
int josephus(int n,int k){
    if(n==1)return 1;
    return (josephus(n-1,k)+k-1)%n+1;
}
int main(){
    int n,k;
    cin>>n>>k;
    cout<<josephus(n,k);
    return 0; 
}