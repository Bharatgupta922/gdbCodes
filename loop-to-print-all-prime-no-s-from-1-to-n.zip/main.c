#include <stdio.h>
int main()
{
    int n,fact;
   
    scanf("%d",&n);
   
    for(int i=1; i<=n; i++)
    {
        fact=0;
        for(int j=1; j<=n; j++)
        {
            if(i%j==0)
                fact++;
        }
        if(fact==2)
            printf("%d\n" ,i);
    }
    
    return 0;
}