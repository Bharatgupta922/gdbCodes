/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int base ,height , area ;
 printf("enter the height");
 scanf("%d",&height);
 printf("\n enter the base");
scanf("%d",&base);
area = (height*base)/2;
printf("the area is%d",area);
    return 0;
}
