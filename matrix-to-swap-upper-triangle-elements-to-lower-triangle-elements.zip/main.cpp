#include<iostream>
using namespace std;
int main(){
    int t ;
    cin>>t;
    while(t--){
        int n ;
        cin>>n;
        int a[n][n];
         for(int i =0;i<n;i++)
         for(int j=0;j<n;j++)
         i==j?cin>>a[i][j]:cin>>a[j][i];
         for(int i=0;i<n;i++){
             for(int j=0;j<n;j++)
             cout<<a[i][j]<<" ";
             cout<<endl;
         }
         cout<<endl;
    }
    return 0;
}