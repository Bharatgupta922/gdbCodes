#include <iostream>
using namespace std;
int main(){
    int n ;
    cin>>n;
    int a[n];
    for(int i =0;i<n;i++)cin>>a[i];
    int k =a[0];
    for(int i =0;i<n;i++)if(k<a[i])k=a[i];
    cout<<k<<endl;
    int b[n],count[k];
    for(int i =0;i<n;i++)++count[a[i]];
    for(int i =1;i<k;i++)count[i]+=count[i-1];
    for(int i=n-1;i>=0;i--)b[--count[a[i]]]=a[i];
    for(int i =0;i<n;i++)cout<<b[i]<<" ";
    return 0;
}