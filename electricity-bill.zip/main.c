/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a,b,c;
  scanf("%f",&a);
  if(a<=50){
    b = 0.5*a;
    c = b + 0.2*b;
    printf("your electricity bill is of %f rupees",c);
  }
 else if (a<=150 && a >50){
    b = 50*0.5 +(a-50)*0.55;
   c =  b + b*0.2;
    printf("your electricity bill is of %f rupees ",c);
   
  }
  else if (a<=250 && a>150){
    b=50*0.5+100*0.75+(a-150)*1.2;
    c= b+b*0.2;
    printf("your electricity bill is of %f rupees ",c);
  }
  else if (a>250){
    b=50*0.5+100*0.75+100*1.2+(a-250)*1.5;
    c=b+b*0.2;
    printf("your elestricity bill is of %f rupees ",c);
  }

    return 0;
}

