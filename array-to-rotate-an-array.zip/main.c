/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int n,j,nr,temp,a[100],i,k,l;
scanf("%d",&n);
for(i=0;i<n;i++)
scanf("%d",&a[i]);
scanf("%d",&nr);
for(j=0;j<nr;j++){
temp=a[0];
for( k=0;k<n-1;k++){
a[k]=a[k+1];
}
a[k]=temp;
}
for(l=0;l<n;l++)
printf("%d ",a[l]);
 return 0;
}
