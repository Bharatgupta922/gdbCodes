/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
float cp , sp ,result;
  scanf("%f",&cp);
  scanf("%f",&sp);
  if(cp>sp){
    result = cp - sp;
    printf("you are in loss of Rs: %f",result);
  }
  else if (sp>cp){
    result = sp - cp ;
    printf("you are in profit of Rs: %f",result);
  }
  else {
    printf("you are in no profit and no loss");
  }
    

    return 0;
}
