#include <stdio.h>
#include<stdlib.h>
int main()
{
// FILE * ptr ;
// char s[100];
// ptr = fopen("f1.txt","w");
// if(ptr==NULL)
// {
//     printf("file cannot open\n");
// exit(1);
// }
// printf("Enter the content\n");
// gets(s);
// for(int i=0;s[i];i++){
//     fputc(s[i],ptr);
// }
// fclose(ptr);


//code to read from file 

// FILE *fp;
// char ch ;
// fp = fopen("f1.txt","r");
// if(fp==NULL){
//     printf("File Not Found !\n");
//     exit(1);
// }
// ch = fgetc(fp);
// while(!feof(fp)){
//     printf("%c",ch);
//     ch = fgetc(fp);
// }
// fclose(fp);

// fgets()

// char str[10];
// FILE * fp ;
// fp = fopen("f1.txt","r");
// if(fp==NULL){
//     printf("File Not Found !");
//     exit(1);
// }

// while(fgets(str,9,fp)!=NULL){
//     printf("%s\n",str);
// }
// fclose(fp);


//fputs();

FILE *fp;
fp = fopen("f1.txt","w");
if(fp==NULL){
    printf("file not found !\n");
    exit(1);
}
printf("What you want to write in your file\n");
char str[25];
gets(str);
fputs(str,fp);`
fp = fopen("f1.txt","r");
while(fgets(str,10,fp)!=NULL){
    printf("%s",str);
}
fclose(fp);


    return 0;
}
