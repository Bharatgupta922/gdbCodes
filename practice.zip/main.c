#include <stdio.h>
#include<math.h>
int main()
{
//  int a = 1, b = 1;
// for(++a && --b ; a<10; a+=2)
// {
// printf("%d%d",a,b);
// }



//  int a=5,b=3;

//  switch(a+=b-=a+=b)
//  {
//  case 1:
//  printf("one");
//  break;
//  case 2:
//  printf("two");
//  break;
//  case 3:
//  printf("three");
//  break;
//  case 4:
//  printf("four");
//  break;
//  default:
//  printf("default");
//  break;

//  }


// int i=0;
// for(i=0;i<20;++i)
// {
// switch(i)
// {
// case 0: i+=5;
// case 1: i-=2;
// case 5: i+=6;
// default: i+=4;
//  }
//  printf("%d ",i);
//  }


//  int i=0;
//  while(i++<=100);
//  printf("%d ", i);



//  int i=0;
//  for(;i<=10;)
//  {
//  if(i++%2)
//  printf("%d ",i);

//  }

//   int i = 2;
//   switch(i)
//   {
//       printf("This is c program.");
//       case 2:
//           printf("Case2");
//           break;
//       case 3:
//           printf("Case3");
//           break;
//   }

// int i =4;
// if(i+2){
//     printf("%d",i);
// }

// double a =120999.459;
// int c = log10(a);
// printf("%d",c);


// double no =3.445805;
// int count =0;
// while(no!=((int)no))
// {
//     count++;
//     no=no*10;
// }
// printf("%d",count);

int f = 194;

int a = (int)f;
printf("%d",(int)a);
    return 0;
}