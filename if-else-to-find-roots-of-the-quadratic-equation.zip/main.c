/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
int main()
{
int a,b,c,d,x1,x2;
printf("enter the coefficient of x^2\n");
scanf("%d",&a);
printf("\nenter the coefficient of x\n");
scanf("%d",&b);
printf("\nenter the constant value\n");
scanf("%d",&c);
d=pow(b,2)-4*a*c;
if(d>=0){
x1=(-b+sqrt(d))/2*a;
x2=(-b-sqrt(d))/2*a;
printf("\nfirst root is %d",x1);
printf("\nsecond root is %d",x2);
}
else{
    printf("it will have complex roots");
}

    return 0;
}
