/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a ;
scanf("%d",&a);
if(a<=50)
{
   printf("The level of Air quality is Healthy\n");
  printf("AQI %d",a);
}
else if (a>50 && a<=100)
{
  printf("The level of Air quality is Moderate\n");
  printf("AQI %d",a);
}
else if(a>100 &&a<=200)
{
  printf("The level of Air quality is Unhealthy\n");
  printf("AQI %d",a);
}

else if(a>200 &&a<=300)
{
  printf("The level of Air quality is Very Unhealthy\n");
  printf("AQI %d",a);
}
else if(a<=500)
{
  printf("The level of Air quality is Hazardous\n");
  printf("AQI %d",a);
}

    return 0;
}
