/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
 //Write Your C
int a,b,c,d;
float r1,r2;
scanf("%d",&a);
printf("\n");
scanf("%d",&b);
printf("\n");
scanf("%d",&c);
d=(b*b)-(4*a*c);
if(d>0){
  printf("Roots are real and distinct");
  r1=(-b+sqrt(d))/(2*a);
    r2=(-b-sqrt(d))/(2*a);
  printf("\nRoot1=%f",r1);
  printf("\nRoot2=%f",r2);
  
}
if(d==0){
  printf("Roots are equal");
  r1=r2=(-b)/(2*a);
 printf("\nRoot1=%f",r1);
  printf("\nRoot2=%f",r2);
}
if(d<0){
  printf("Roots are imaginary");
}

    return 0;
}

