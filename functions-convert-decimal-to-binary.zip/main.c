  #include <stdio.h> 
  int binary(int n);
    int main() 
    { 
    int n,b;
    scanf("%d",&n);
   int result = binary(n);
   printf("%d",result);
    }
    int binary(int n ){
        int binary=0,rem,i=1;
while(n>0){
    rem =n%2;
    binary=binary+rem*i;
    n/=2;
    i*=10;
}
return binary;

    } 

