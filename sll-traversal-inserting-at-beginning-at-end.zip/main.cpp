#include <iostream>
using namespace std;
struct node{
    int data ;
     node *link;
    };
node * head = NULL;
node * tail=NULL;
int main()
{
  node *first = new node();
  node *second = new node();
  node *third = new node();
  node *fourth  = new node();
  node *fifth=new node();
  node * sixth=new node();
    head=first ;
  first->data=1;
    first->link=second;
  second->data=2;
      second->link=third;
  third ->data=3;
      third->link=NULL;
      tail=third;
      node * n=head;
  while(n!=NULL){
      cout<<n->data<<endl;
      n=n->link;
  }
  cout<<"now inserting at the beginning ";
  cout<<endl<<endl;
  cout<<"input the data for the node to be added in the begginnning ";
  int a;
  cout<<endl;
  cin>>a;
  fourth->data=a;
  head = fourth;
  fourth->link=first ;
  node * x=head;
  while(x!=NULL){
      cout<<x->data<<"\t";
      x=x->link;
  }
  cout<<endl<<"--------------------------------------------------------------------------------------"<<endl;
  cout<<"now inserting at the end "<<endl<<"input the value to be inserted at the end "<<endl;
  int b;
  cin>>b;
  fifth->data=b;
  fifth->link=NULL;
//   tail=fifth;
//   third->link=fifth;
//   node * y=head;
//   while(y!=NULL){
//       cout<<y->data<<"\t";
//       y=y->link;
//   }
//or we can traverse th sll till end 
node * temp=head;
while(temp->link!=NULL)temp=temp->link;
temp->link=fifth;
tail = fifth;
  node * y=head;
  while(y!=NULL){
      cout<<y->data<<"\t";
      y=y->link;
  }
cout<<"-----------------------------------------------------------------"<<endl;
cout<<"now insert the position after which you want to insert && data of that node"<<endl;
int pos,i=1 ;
cin>>pos;
cin>>sixth->data;
temp=head;
while(i<pos){
    temp=temp->link;
    i++;
}
sixth->link=temp->link;
temp->link=sixth;
node * z=head;
while(z!=NULL){
    cout<<z->data<<"\t";
    z=z->link;
}
  return 0;
}
