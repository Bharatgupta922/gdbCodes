#include <iostream>
#include<cctype>
#include<cstdlib>
////or we can use #include<locale> also
using namespace std ;
int main()
{
int i =0;
char str[]="c3poo...";
while(isalnum(str[i]))i++;
cout<<"the first "<<i<<" character are alphanumeric"<<endl;
cout<<"-------------------------------------------------------"<<endl;
i=0;
char str1[]="c++";
while(str1[i]){
    if(isalpha(str1[i]))cout<<str1[i]<<" is alphabetic"<<endl;
    else cout<<str1[i]<<" not alphabetic"<<endl;
    i++;
}
cout<<endl<<"----------------------------------------------------"<<endl;
    char c;
  i=0;
  char str2[]="Example sentence to test isblank\n";
  while (str2[i]){
    c=str2[i];
    if (isblank(c)) c='\n';
    cout<<c;
    i++;
  }
  cout<<endl<<"--------------------------------------------------"<<endl;
 i=0;
  char str3[]="first line \n second line \n";
  while (!iscntrl(str3[i]))
  {
cout<<str3[i];
    i++;
  } 
 cout<<endl<<"-----------------------------------------------------------------"<<endl;
  i=0;
  static int count ;
  char str4[]="178948bharat";
  while(str4[i]){
      if(isdigit(str4[i]))count++;
      i++;
  }
      cout<<"given string has "<<count<<" digits in it";
 cout<<endl<<"------------------------------------------------------------------"<<endl;
    i=0;
    char str5[]="Test String.\n";
    while(str5[i]){
        if(islower(str5[i]))str5[i]=toupper(str5[i]);
        i++;
    }
    cout<<str5;
 cout<<endl<<"------------------------------------------------------------------"<<endl;
    i=0;
  char str6[]="first line \n second line \n";
  while (isprint(str6[i]))
  {
   cout<<str6[i];
    i++;
  }  
  cout<<endl<<"-----------------------------------------------------------------"<<endl;
  i=0;
  int cx=0;
  char str7[]="Hello, welcome!";
  while (str7[i])
  {
    if (ispunct(str7[i])) cx++;
    i++;
  }
  cout<<"Sentence contains "<<cx<<" punctuation characters.";
  cout<<endl<<"------------------------------------------------------------------------------------------------"<<endl;
  i=0;
  char str8[]="Example sentence to test isspace\n";
  while (str8[i])
  {
    c=str8[i];
    if (isspace(c)) c='\n';
    cout<<c;
    i++;
  }
  cout<<endl<<"------------------------------------------------------------------------------------------------"<<endl;
   char str9[]="ffff";
  long int number;
  if (isxdigit(str9[0]))
  {
    number = strtol (str,NULL,16);
    cout<<hex<<number;
  }
  cout<<endl<<"------------------------------------------------------------------------------------------------"<<endl;
    return 0;
}


