/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int a,b,c,max;
  scanf("%d",&a);
   scanf("%d",&b);
    scanf("%d",&c);
if (a>b){
    if(a>c){
    max=a;
    printf("maximum no. is %d",max);
    }
    else{
        max = c;
        printf("maximum no. is %d",max);
    }
}
else{
    if (b>c){
        max=b;
        printf("maximum no. is %d",max);
    }
  else {
      max = c;
      printf("maximum no. is %d",max);
  }
}
    return 0;
}
