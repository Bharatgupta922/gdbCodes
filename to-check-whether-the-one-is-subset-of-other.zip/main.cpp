#include <iostream>
#include<algorithm>
#include<set>
using namespace std;
int main() {
	int t ;
	cin>>t;
	while(t--){
	    int m,n,temp;
	    cin>>m>>n;
	   set <int> a,b;
	   bool present = true ;
	   for(int i=0;i<m;i++){
	       cin>>temp;
	       a.insert(temp);
	   }
	   for(int i=0;i<n;i++){
	       	       cin>>temp;
	       b.insert(temp);
	   }
	   for(set<int>::iterator it=b.begin();it!=b.end();it++){
	       if(!binary_search(a.begin(),a.end(),*it)){
	           cout<<"NO"<<endl;
	           present = false;
	           break;
	       }
	   }
	   if(present)cout<<"YES"<<endl;
	}
	return 0;
}