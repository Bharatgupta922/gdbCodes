/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
double pie=3.14;
double r ;
scanf("%lf",&r);
double circumference ;
circumference = 2*pie*r;
printf("your circumference is %lf\n",circumference);
double area ;
 area = pie*r*r;
printf("your area is %lf\n",area);
double diameter ;
 diameter = 2*r;
printf("your diameter is %lf\n",diameter);
return 0;
}
