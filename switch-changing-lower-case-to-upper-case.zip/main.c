/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{

      
     int n ;
     char ch,result;
  printf("1. Lowercase to Uppercase\n");
  printf("2. Uppercase to Lowercase\n");
  printf("Enter your Option: ");
   scanf("%d",&n);
   if(n==1){
         printf("Enter a lowercase character :");
         scanf(" %c",&ch);
         if(ch>=97&&ch<=122){
         result=ch-32;
         printf("Uppercase character : %c",result);
         }
         else
         printf("%c  not a lowercase character",ch);
   }
   else if(n==2){
    printf("Enter a Uppercase character :"); 
     scanf(" %c",&ch);
     if(ch>=65&&ch<=90){
         result = ch+32;
         printf("Lowercase character : %c",result);
     }
     else
     printf("%c is not a Uppercase character",ch);
     }
     else
     printf("Please enter a valid option ");

    return 0;
}


