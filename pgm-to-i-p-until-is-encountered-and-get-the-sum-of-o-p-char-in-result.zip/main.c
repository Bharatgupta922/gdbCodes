/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int sum=0;
    while(1){
        char c;
        scanf(" %c",&c);
        if(c== '*')
        break;
        else{
            sum+=c;
        }
        
    }
    int check = sum%10;
printf("%d\n",sum);
if(check%2==0)
printf("Even");
else
printf("Odd");
    return 0;
}
