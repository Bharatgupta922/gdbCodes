/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a ;
printf("enter the month no.");
scanf("%d",&a);
if(a==1||a==3||a==5||a==7||a==8||a==10||a==12){
    printf("31 days in this month ");
}
else if(a==2){
    printf("28 days and in leap year there are 29 days ");
}
else {
    printf("30 days in this month ");
}

    return 0;
}
