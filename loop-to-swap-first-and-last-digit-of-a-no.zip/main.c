/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
  int n,lastdigit,firstdigit,count=0,a,temp,result=0,z;
scanf("%d",&n);
a=n;
count=(int)log10(a)+1;
lastdigit=n%10;
while(n>10)n/=10;
firstdigit=n;
result = (lastdigit*pow(10,count-1)+firstdigit)+(a-firstdigit*pow(10,count-1)-lastdigit);
printf("%d",result);

    return 0;
}

