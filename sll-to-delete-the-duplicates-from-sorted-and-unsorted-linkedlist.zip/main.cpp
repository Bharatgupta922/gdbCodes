#include<unordered_set>
Node * removeDuplicates( Node *head) 
{
 if(head==NULL)return head;
 unordered_set <int> s;
 Node * first = head ;
 Node * second = NULL;
 do{
     if(s.find(first->data)!=s.end()){
         while(first && (first->data==second->data || s.find(first->data)!=s.end()))first=first->next;
         second->next = first;
     }
     if(first==NULL)return head;
         s.insert(first->data);
     second = first ;
     first = first->next;
 }while(first!=NULL);
 return head;
}
