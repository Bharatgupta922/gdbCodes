/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int num,n2000,n500,n100,n50,n20,n10,n5,n2,n1;
 printf("enter the amount");
 scanf("%d",&num);
 n2000=num/2000;
 num=num%2000;
 printf("no of 2000 are %d",n2000);
 n500=num/500;
 num=num%500;
 printf("\nno of 500 are %d",n500);
 n100=num/100;
 num=num%100;
 printf("\nno of 100 are %d",n100);
 n50=num/50;
 num=num%50;
 printf("\nno of 50 are %d",n50);
  n20=num/20;
 num=num%20;
 printf("\nno of 20 are %d",n20);
  n10=num/10;
 num=num%10;
 printf("\nno of 10 are %d",n10);
 n5=num/5;
 num=num%5;
 printf("\nno of 5 are %d",n5);
  n2=num/2;
 num=num%2;
 printf("\nno of 2 are %d",n2);
  n1=num/1;
 num=num%1;
 printf("\nno of 1 are %d",n1);
    return 0;
}

