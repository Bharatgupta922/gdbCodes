/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdbool.h>

int main()
{
 int n ;
 scanf("%d",&n);
 int a[n];
 for(int i=0;i<n;i++)
scanf("%d",&a[i]);
for(int j=0;j<n-1;j++){
bool sorted=true;
 for(int k=0;k<n-j-1;k++)
     if(a[k+1]<a[k]){
         int temp =a[k+1];
         a[k+1]=a[k];
         a[k]=temp;
         sorted = false;
     }
     if(sorted)
     break;
}
for(int i=0;i<n;i++){
    printf("%d ",a[i]);
}

    return 0;
}
